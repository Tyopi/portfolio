from fltk import *
import random
import time
import os

# complexiter = O(LIGNE x COLONNE + n²)

LARGEUR= 400
HAUTEUR = 800
LARGEUR_FENETRE= 600
COLONNE = 12
LIGNE = 24



    


def dessiner_grille(grille):
    for i in range(LIGNE):
        for j in range(COLONNE):           
            rectangle(j * (LARGEUR / COLONNE), i * (HAUTEUR / LIGNE),
                    (j + 1) * (LARGEUR / COLONNE), (i + 1) * (HAUTEUR / LIGNE),
                    remplissage=couleur(grille[i][j]))  
            
 

PIECES3 = [
         [[0, 1,0],
          [0, 1,0],
          [0, 1,0]],
          [[0, 1],
          [1, 1,]],
    
    
]

PIECES4 = [
         [[0, 1, 0, 0],
          [0, 1, 0, 0],
          [0, 1, 0, 0],
          [0, 1, 0, 0]],
    
         [[0, 1, 1],
          [0, 1, 0],
          [0, 1, 0]],
    
         [[1, 1, 0],
          [0, 1, 0],
          [0, 1, 0]],
    
         [[0, 1, 0],
          [1, 1, 0],
          [1, 0, 0]],
    
         [[0, 1, 0],
          [0, 1, 1],
          [0, 0, 1]],
    
         [[1, 1],
          [1, 1]],
    
         [[0, 1, 0],
          [0, 1, 1],
          [0, 1, 0]]
]



def choisir_piece(n):
    if n == 4:
        forme = random.randrange(0,7)
        return PIECES4[forme]
    if n == 3:
        forme = random.randrange(0,2)
        return PIECES3[forme]
    
    return polinome(n)
    '''forme = random.randrange(0,7)
    return PIECES[forme]'''



def polinome(n):
    nouvelle_piece = [[0 for i in range(n)]for j in range (n)]
    nouvelle_piece[random.randrange(1,n)][random.randrange(1,n)] = 1
    a = 0
    while a < n-1:
        nouvelle_ligne = random.randrange(1,n)
        nouvelle_colone = random.randrange(1,n)
        for i in range(n):
            for j in range(n):
                if case_possible(nouvelle_piece, nouvelle_ligne, nouvelle_colone) is True:
                    if nouvelle_piece[nouvelle_ligne][nouvelle_colone] != 1:
                        nouvelle_piece[nouvelle_ligne][nouvelle_colone] = 1
                        a += 1 
  
    return nouvelle_piece

def case_possible(M, ai, aj):
    if M[ai][aj] != 0:
        return False


    for i in range(len(M)):
        for j in range(len(M)):
            if (ai - 1 == i and aj == j) or (ai + 1 == i and aj == j) or (ai == i and aj - 1 == j) or (ai == i and aj + 1 == j):
                if 0 <= i < len(M) or 0 <= j < len(M[0]):
                    if M[i][j] != 0:  
                        return True

    return False




def couleur(nombre):
    if nombre == 0:
        return "white"
    if nombre == 1:
        return "purple"
    if nombre == 2:
        return "pink"
    if nombre == 3:
        return "blue"
    if nombre == 4:
        return "red"
    if nombre == 5:
        return "orange"
    if nombre == 6:
        return "yellow"
    if nombre == 7:
        return "black"


 

def dessiner_piece(piece, x, y, color):
    for i in range(len(piece)):
        for j in range(len(piece[i])):
            if piece[i][j] == 1:
                x1 = (x + j) * (LARGEUR / COLONNE)
                y1 = (y + i) * (HAUTEUR / LIGNE)
                rectangle(x1, y1, x1 + (LARGEUR / COLONNE), y1 + (HAUTEUR / LIGNE), remplissage=couleur(color))  
                

def collision(piece, x, y, grille):
    for i in range(len(piece)):
        for j in range(len(piece[i])):
            if piece[i][j] == 1:
                x2 = x + j
                y2 = y + i
                
                if x2 < 0 or x2 >= COLONNE or y2 >= LIGNE or (y2 >= 0 and grille[y2][x2] > 0):
                    return True
    return False




def rotation(piece):
    return [list(row) for row in zip(*piece[::-1])]  

    



def bouton_arret(x1,y1,x2,y2):
    ev = donne_ev()
    tev = type_ev(ev)
    if x2-5 < abscisse_souris() < x1 and y1 < ordonnee_souris() < y2: 
        for i in range(5):
            ligne(x1-i,y1,x2-i-10,y2+10,"red")
            ligne(x2-i-10,y1,x1-i,y2+10,"red")  
    else:
        for i in range(5):
            ligne(x1-i,y1,x2-i,y2)
            ligne(x2-i,y1,x1-i,y2)    

    if x2-5 < abscisse_souris() < x1 and y1 < ordonnee_souris() < y2 and tev == "ClicGauche":
        return False
    return True



def menu_pause():
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        rectangle(200,0,400,10000, remplissage="white")
        rectangle(200,200,400,300,couleur="pink", remplissage="white",epaisseur="3")
        texte(210,210,'reprendre')
            
        if 200 < abscisse_souris() < 400 and 200 < ordonnee_souris() < 350 and tev == "ClicGauche":
            efface_tout()
            mise_a_jour()   
            return True
            
        rectangle(200,400,400,500,couleur="pink", remplissage="white",epaisseur="3")
        texte(210,410,'sauvgarder')
        texte(210,450,'et quitter')
            
        if 200 < abscisse_souris() < 400 and 400 < ordonnee_souris() < 500 and tev == "ClicGauche":
            efface_tout()
            mise_a_jour()   
            return False
        mise_a_jour()        
        efface_tout()        



def affichage(score,diff,bonus,duree):
    rectangle(550,380,450,410,remplissage="white",epaisseur=3)
    rectangle(550,410,450,440,remplissage="white",epaisseur=3)
    texte(455,380,"score")
    texte(450,475,"level: " + str(diff))
    texte(455,415,score,taille=20,)
    if bonus == 4:
        texte(450,600,"bonus x4")
        texte(450,660,750 - duree)
    

#menu d'aide (a modifiere)
def felp():
    efface_tout()
    mise_a_jour()
    while True :
        ev = donne_ev()
        tev = type_ev(ev)
        texte (100,100,"pour savoir jouer faut faire : ",couleur="black",taille=9)
        rectangle(5,5,20,20,couleur="pink", remplissage="white",epaisseur="3")
        if 5 < abscisse_souris() < 20 and 5 < ordonnee_souris() < 20 and tev=="ClicGauche" :
            efface_tout()
            mise_a_jour()
            break
        if not bouton_arret(10,10,20,20):
            efface_tout()
            mise_a_jour()
            break
        
        mise_a_jour()  
        efface_tout()
     

def menu():
    cree_fenetre(400, 400)
    
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        
        texte(150, 90, "Tetris", couleur="black", taille=30)
        #  Bouton "Help" avec dégradé et animation
        if 15 < abscisse_souris() < 50 and 5 < ordonnee_souris() < 25:
            # Dégradé pour le bouton "Help" au survol
            rectangle(10, 5, 50, 25, couleur="pink", remplissage="lightpink", epaisseur=3)
            texte(15, 10, "Help", couleur="red", taille=12)
            
            if tev == "ClicGauche":
                # Animation simple : effet de changement de taille au clic
                for i in range(10):
                    rectangle(10, 5, 50 + i, 25 + i, couleur="darkviolet", remplissage="purple", epaisseur=3)
                    texte(15, 10, "Help", couleur="yellow", taille=12)
                    mise_a_jour()
                    time.sleep(0.05)
                efface_tout()
                mise_a_jour()  # Réinitialisation après l'animation
                felp()
        else:
            # Apparence normale du bouton "Help"
            rectangle(10, 5, 50, 25, couleur="pink", remplissage="lightpink", epaisseur=1)
            texte(15, 10, "Help", couleur="red", taille=10)

        #  Bouton "Classic" avec dégradé et animation
        if 100 < abscisse_souris() < 300 and 200 < ordonnee_souris() < 250:
            # Dégradé pour le bouton "Classic" au survol
            rectangle(95, 195, 305, 305, couleur="purple", remplissage="lightblue", epaisseur=3)
            texte(105, 210, "Mode de jeux")
            texte(105, 250, "Classic")
            
            if tev == "ClicGauche":
                # Animation de changement de couleur au clic
                for i in range(10):
                    rectangle(95, 195, 305, 305, couleur="purple", remplissage="lightgreen", epaisseur=3)
                    texte(105, 210, "Mode de jeux")
                    texte(105, 250, "Classic")
                    mise_a_jour()
                    time.sleep(0.05)
                efface_tout()
                mise_a_jour()
                ferme_fenetre()   # Réinitialisation après l'animation
                return "jeux de base"
        elif  100 < abscisse_souris() < 300 and 265 < ordonnee_souris() < 315:
            # Dégradé pour le bouton "Classic" au survol
            rectangle(95, 195, 305, 305, couleur="purple", remplissage="lightblue", epaisseur=3)
            texte(105, 210, "Mode de jeux")
            texte(105, 250, "Coruption")
            
            if tev == "ClicGauche":
                # Animation de changement de couleur au clic
                for i in range(10):
                    rectangle(95, 195, 305, 305, couleur="purple", remplissage="lightgreen", epaisseur=3)
                    texte(105, 210, "Mode de jeux")
                    texte(105, 250, "coruption")
                    mise_a_jour()
                    time.sleep(0.05)
                efface_tout()
                mise_a_jour()
                ferme_fenetre()   # Réinitialisation après l'animation
                return "cor"
        else:
            # Apparence normale du bouton "Classic"
            rectangle(100, 200, 300, 250, couleur="purple", remplissage="lightblue", epaisseur=3)
            texte(140, 210, "Classic")
            rectangle(100, 265, 300, 315, couleur="purple", remplissage="lightblue", epaisseur=3)
            texte(140, 275, "Coruption")
        
        # --- Bouton "Arret" avec dégradé et animation ---
        if 350 < abscisse_souris() < 400 and 0 < ordonnee_souris() < 50:
            # Dégradé pour le bouton "Arret"
            rectangle(350, 0, 400, 50, couleur="red", remplissage="darkred", epaisseur=3)
            texte(355, 10, "Arret", couleur="white", taille=12)
            
            if tev == "ClicGauche":
                # Animation de changement de couleur et de taille au clic
                for i in range(10):
                    rectangle(350-i, 0-i, 400 + i, 50 + i, couleur="darkred", remplissage="black", epaisseur=3)
                    texte(355, 10, "Arret", couleur="yellow", taille=12)
                    mise_a_jour()
                    time.sleep(0.05)
                efface_tout()  # Réinitialisation après l'animation

                mise_a_jour()
                ferme_fenetre()
                print("//////// fin de programme ////////")
                return "arret"
        else:
            # Apparence normale du bouton "Arret"
            rectangle(350, 0, 400, 50, couleur="red", remplissage="darkred", epaisseur=3)
            texte(355, 10, "Arret", couleur="white", taille=12)

        mise_a_jour()
        efface_tout()


        
        
        
def fichier(nom_fichier):
    liste_ligne = []
    try:
        with open("tp python/tetris/parametre.txt.txt") as fichier:
            liste_ligne = (fichier.readlines())
        return liste_ligne
    except FileNotFoundError:
        print(f"Erreur : Le fichier parametre.txt est introuvable.")
        return []




        

    





def jeu_principal(mode):
    cree_fenetre(LARGEUR_FENETRE, HAUTEUR)
    a = 0
    while True:
        ev = donne_ev()
        tev = type_ev(ev)
        rectangle(100,200,300,250,couleur="pink", remplissage="white",epaisseur="3")
        texte(140,210,'parametre avec le fichier')
        
        if 100 < abscisse_souris() < 300 and 200 < ordonnee_souris() < 250 and tev == "ClicGauche":
            choix = False
            break
          
        rectangle(100,250,300,300,couleur="pink", remplissage="white",epaisseur="3")
        texte(140,260,'choisir')
                
        if 100 < abscisse_souris() < 300 and 250 < ordonnee_souris() < 300 and tev == "ClicGauche":
            choix = True
            break
        mise_a_jour()        
        efface_tout()

    mise_a_jour()        
    efface_tout()  
        


    if choix == False:
        parametre = fichier("tp python/tetris/parametre.txt.txt")
        print(parametre)
        if parametre[0] == 'facile\n':
            vitesse = 10
            ligne_a_sprimer = 15
            vitesse_pourisement = 0
            print("mode facile choisi")
            multiplicateur_point = 0.5

        if parametre[0] == "moyen\n":
            ligne_a_sprimer = 15
            vitesse = 10            
            multiplicateur_point = 0.5
            vitesse_pourisement = 50
            print("mode moyen choisi")
            diffff = "difficulter: myen"  

        if parametre[0] == "difficile\n":
            ligne_a_sprimer = 15
            vitesse = 10
            multiplicateur_point = 2
            vitesse_pourisement = 150
            print("mode difficle choisi")
            diffff = "difficulter: dificile"  


        taille = int(parametre[1])

    if choix == True:
        ev = donne_ev()
        tev = type_ev(ev)
        while True:
            ev = donne_ev()
            tev = type_ev(ev)
            rectangle(100,200,300,250,couleur="pink", remplissage="white",epaisseur="3")
            texte(140,210,'facile')

            if 100 < abscisse_souris() < 300 and 200 < ordonnee_souris() < 250 and tev == "ClicGauche":
                vitesse = 10
                ligne_a_sprimer = 15
                vitesse_pourisement = 0
                print("mode facile choisi")
                multiplicateur_point = 0.5
                break

                
                
            rectangle(100,250,300,300,couleur="pink", remplissage="white",epaisseur="3")
            texte(140,260,'moyen')

            if 100 < abscisse_souris() < 300 and 250 < ordonnee_souris() < 300 and tev == "ClicGauche":
                ligne_a_sprimer = 15
                vitesse = 10            
                multiplicateur_point = 0.5
                vitesse_pourisement = 50
                print("mode moyen choisi")
                diffff = "difficulter: myen"  
                break

            rectangle(100,300,300,350,couleur="pink", remplissage="white",epaisseur="3")
            texte(140,310,'difficile')

            if 100 < abscisse_souris() < 300 and 300 < ordonnee_souris() < 350 and tev == "ClicGauche":
                ligne_a_sprimer = 15
                vitesse = 10
                multiplicateur_point = 2
                vitesse_pourisement = 150
                print("mode difficle choisi")
                diffff = "difficulter: dificile"  
                break
            mise_a_jour()        
            efface_tout()

        mise_a_jour()        
        efface_tout()  


        while True:
            ev = donne_ev()
            tev = type_ev(ev)
            rectangle(50,300,100,350,couleur="pink", remplissage="white",epaisseur="3")
            texte(60,310,'3')

            if 50 < abscisse_souris() < 100 and 300 < ordonnee_souris() < 350 and tev == "ClicGauche":
                print("3")
                taille = 3
                break



            rectangle(150,300,200,350,couleur="pink", remplissage="white",epaisseur="3")
            texte(160,310,'4')

            if 150 < abscisse_souris() < 200 and 300 < ordonnee_souris() < 350 and tev == "ClicGauche":
                print("4")
                taille = 4
                break
                
            rectangle(250,300,300,350,couleur="pink", remplissage="white",epaisseur="3")
            texte(260,310,'5')

            if 250 < abscisse_souris() < 300 and 300 < ordonnee_souris() < 350 and tev == "ClicGauche":
                print("5")
                taille = 5
                break
                
            mise_a_jour()        
            efface_tout()

        efface_tout()
        mise_a_jour()

    
    while a < 3:
        texte(400,300,3 - a)
        a += 1
        mise_a_jour()        
        time.sleep(1)
        efface_tout()

    grille = [[0] * COLONNE for _ in range(LIGNE)]  
    piece_suivante = choisir_piece(taille)
    piece = choisir_piece(taille)
    couleur_piece_suivante = random.randrange(1,7)
    couleur_piece = random.randrange(1,7)
        
    score = 0
    lignes_supprimees = 0   
    ligne_total = 0
    addition = 0
        
                
    grille = [[0] * COLONNE for _ in range(LIGNE)]  
    piece_suivante = choisir_piece(taille)
    piece = choisir_piece(taille)
    couleur_piece_suivante = random.randrange(1,7)
    couleur_piece = random.randrange(1,7)
    emplacement_bonus = ()
    score = 0
    lignes_supprimees = 0   
    ligne_total = 0
    addition = 0
        
    difficulter = 0                
    a = 450    
    x = COLONNE // 2 - len(piece[0]) // 2
    y = 0   

    DERNIER_MOUVEMENT = 3
    COOLDOWN_MOUVEMENT = 15

    DERNIER_ROTATION = 3
    COOLDOWN_ROTATION = 6

    DERNIER_DECALAGE = 3
    COOLDOWN_DECALAGE = 4

    COOLDOWN_bonus = 750
    timing_COOLDOWN_bonus = -200   
    vie_bonus = 1000
    timing_vie_bonus = 0
    durée_bonus = 750
    timing_durée_bonus = 0

    DERNIER_cooruption = 6
    COOLDOWN_cooruption = 500 - vitesse_pourisement
    
    COOLDOWN_MOUVEMENT += vitesse

    bonus_pris = False
    
    while True:


        
        '''chrono et accelerateur'''

        if timing_COOLDOWN_bonus < COOLDOWN_bonus:
            timing_COOLDOWN_bonus += 1
            bonus = 1
        else:
            if emplacement_bonus == ():
                d = True
                while d == True:
                    xs = random.randrange(0,12)
                    ys = random.randrange(0,24)
                    if grille[ys][xs] != 0:
                        emplacement_bonus = (ys,xs)
                        d = False

            if timing_vie_bonus < vie_bonus :
                if bonus_pris == True:
                    if timing_durée_bonus < durée_bonus:
                        timing_durée_bonus += 1
                        bonus = 4
                        emplacement_bonus = ()
                    else:
                        bonus = 1
                        timing_COOLDOWN_bonus = 0
                        timing_vie_bonus = 0
                        timing_durée_bonus = 0
                        bonus_pris = False 
                        emplacement_bonus = ()
                else:
                    timing_vie_bonus += 1
                    bonus = 1
                
            else:
                timing_COOLDOWN_bonus = 0
                timing_vie_bonus = 0
                timing_durée_bonus = 0
                bonus_pris = False 
                bonus = 1
                emplacement_bonus = ()
        
        print(timing_COOLDOWN_bonus,timing_vie_bonus,timing_durée_bonus,bonus,emplacement_bonus)

        DERNIER_MOUVEMENT += 1
        DERNIER_ROTATION += 1
        DERNIER_DECALAGE += 1
        DERNIER_cooruption += 1
        
        if ligne_total >= int(ligne_a_sprimer) and ligne_total != 0:
            difficulter += 1
            COOLDOWN_MOUVEMENT = 15 - difficulter * 3 
            ligne_total -= int(ligne_a_sprimer)
            COOLDOWN_DECALAGE = 4 - difficulter //2
            if COOLDOWN_MOUVEMENT < 5:
            	COOLDOWN_MOUVEMENT = 5
        diff = difficulter

        new_grille = []
        lignes_supprimees = 0
                
        '''effaceur de ligne'''


        for i in range(len(grille)):
            compteur = 0
            for j in range(len(grille[0])):  
                if (type(grille[i][j]) == int and grille[i][j] > 0):
                    compteur += 1
                if compteur == 12:
                    lignes_supprimees +=1         
                    if emplacement_bonus != () and emplacement_bonus[0] == i:
                        bonus_pris = True 
                    grille.pop(i)
                    grille.insert(0, [0]*12)
        '''score'''  

        if lignes_supprimees == 1:
            score += int(40 * (difficulter+1) * multiplicateur_point * bonus)
            addition = int(40 * (difficulter+1) * multiplicateur_point * bonus)
            a = 0
        if lignes_supprimees == 2:
            score += int(100 * (difficulter+1) * multiplicateur_point * bonus)
            addition = int(100 * (difficulter+1) * multiplicateur_point * bonus)
            a = 0
        if lignes_supprimees == 3:
            score += int(300 * (difficulter+1) * multiplicateur_point * bonus)
            addition = int(300 * (difficulter+1) * multiplicateur_point * bonus)
        if lignes_supprimees >= 4:
            score += int(500 * (difficulter+1) * multiplicateur_point * bonus)
            addition = int(500 * (difficulter+1) * multiplicateur_point * bonus)
            a = 0
        ligne_total += lignes_supprimees
        lignes_supprimees = 0

        if addition > 0 and a < 12:
            a += 1
            t = "+" + str(addition)
            texte(455,230,t)


        '''piece qui tombe'''

        
        if DERNIER_MOUVEMENT >= COOLDOWN_MOUVEMENT:
            DERNIER_MOUVEMENT = 0  
            
            if not collision(piece, x, y + 1, grille):
                y += 1
                
            else:
                for i in range(len(piece)):
                    for j in range(len(piece[i])):
                        if piece[i][j] > 0:
                            grille[y + i][x + j] = couleur_piece 

                
                couleur_piece = couleur_piece_suivante
                piece = piece_suivante

                couleur_piece_suivante = random.randrange(1,7)
                piece_suivante = choisir_piece(taille)
                
                x = COLONNE // 2 - len(piece[0]) // 2
                y = 0

               
                if collision(piece, x, y, grille):
                    print("/////// fin de programme par defaite ///////")
                    break  



                    '''Touche'''


        if touche_pressee('Down'):
            if not collision(piece, x, y + 1, grille):
                y += 1
                
            else:
                for i in range(len(piece)):
                    for j in range(len(piece[i])):
                        if piece[i][j] > 0:
                            grille[y + i][x + j] = couleur_piece 

                
                couleur_piece = couleur_piece_suivante
                piece = piece_suivante

                couleur_piece_suivante = random.randrange(1,7)
                piece_suivante = choisir_piece(taille)
                
                x = COLONNE // 2 - len(piece[0]) // 2
                y = 0

               
                if collision(piece, x, y, grille):
                    print("/////// fin de programme par defaite ///////")
                    break


        

        if touche_pressee('Right'):
            if DERNIER_DECALAGE >= COOLDOWN_DECALAGE: 
                if not collision(piece, x + 1, y, grille):  
                    x += 1
                DERNIER_DECALAGE = 0

        if touche_pressee('Left'):
            if DERNIER_DECALAGE >= COOLDOWN_DECALAGE:  
                if not collision(piece, x - 1, y, grille):  
                    x -= 1
                DERNIER_DECALAGE = 0

        


                if collision(piece, x, y, grille):
                    print("/////// fin de programme par defaite ///////")
                    efface_tout()
                    mise_a_jour()
                    break 

        if touche_pressee('Up'):
            if DERNIER_ROTATION >= COOLDOWN_ROTATION: 
                piece_tournée = rotation(piece)
                if not collision(piece_tournée, x, y, grille):  
                    piece = piece_tournée
                DERNIER_ROTATION = 0

        if not bouton_arret(600,0,550,50):
            on_fait_quoi = menu_pause()
            efface_tout()
            mise_a_jour()
        
            if on_fait_quoi is True:
                pass
            if on_fait_quoi is not True:
                efface_tout()
                mise_a_jour()
                print("arret par bouton arret")
                break

        if mode == "cor":
            if DERNIER_cooruption >= COOLDOWN_cooruption:
                f = True
                while f == True:
                    xs = random.randrange(0,12)
                    ys = random.randrange(0,24)
                    if grille[ys][xs] != 0:
                        grille[ys][xs] = 0
                        DERNIER_cooruption = 0
                        print("suprimer")
                        f = False

  
        dessiner_grille(grille) 
        dessiner_piece(piece, x, y, couleur_piece)     
        dessiner_piece(piece_suivante, 12.5, 4, couleur_piece_suivante)
        if emplacement_bonus != ():
            dessiner_piece([[1]], emplacement_bonus[1], emplacement_bonus[0], random.randrange(0,8))     
        affichage(score,diff,bonus,timing_durée_bonus)      
        mise_a_jour()
        efface_tout()


        time.sleep(0.01)

    print("")
    print("votre score est de: " + str(score))  
    print("") 

if __name__ == "__main__":
    mode = menu()
    if mode == "jeux de base":
        jeu_principal("jeux de base")

    if mode == "cor":
        jeu_principal("cor")
     
    if mode == "arret":
        print("/////// fin de programme par arret volontaire depuis le menu ///////")
        pass  
        
        
           
